SHIVAM PAYROLL - MOBILE APK CLOUD BUILD

Ye project phone se GitHub Actions ke through APK banane ke liye ready hai.

1. Is poore folder ko GitHub repository me upload karein.
2. Repository me Actions kholen.
3. "Build Shivam Payroll APK" workflow run karein.
4. Build complete hone ke baad Artifacts me "Shivam-Payroll-APK" download karein.
5. ZIP kholkar app-debug.apk install karein.

Note: Supabase publishable key app ke HTML me already configured hai. Supabase secret/service-role key app me kabhi na daalein.
